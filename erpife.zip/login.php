<html>
  <head>
    <title></title>
    <meta content="">
    <style></style>
	<script language="javascript" type="text/javascript" src="niceforms.js"></script>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  </head>

<form name="form_ingreso" method="POST" action="control.php">
<center>
<fieldset>
<legend>Ingreso</legend>
	<dl>
		<dt><label for="username">Usuario: </label></dt>
		<dd><input type="text" name="username"></dd>
	</dl>
	<dl>
		<dt><label for="password">Contrase�a: </label></dt>	
		<dd><input type="password" name="password"></dd>
	</dl>
	<dl>
		<input type="submit" name="enviar" value="Enviar">
	</dl>
</fieldset>
</center>
</form>
